// Dark Mode Persistence
document.addEventListener('DOMContentLoaded', () => {
    const isDark = localStorage.getItem('bankease_dark_mode') === 'true';
    if (isDark) {
        document.body.classList.add('dark-mode');
    }
});

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('bankease_dark_mode', isDark);
}
